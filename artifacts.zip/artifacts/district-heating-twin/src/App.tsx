import { useMemo, useState } from 'react';
import {
  Activity, AlertTriangle, ArrowDownRight, ArrowUpRight, ChevronDown,
  Clock3, Download, Flame, Gauge, RefreshCw, SlidersHorizontal,
  Thermometer, Waves, Zap,
} from 'lucide-react';
import {
  Area, AreaChart, CartesianGrid, Line, LineChart, ReferenceLine,
  ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts';

type Reading = {
  time: number;
  supply: number;
  returned: number;
  delivered: number;
  ambient: number;
  flow: number;
  anomaly: boolean;
};

function createRandom(seed: number) {
  let state = seed >>> 0;
  return () => {
    state = (state + 0x6d2b79f5) >>> 0;
    let value = state;
    value = Math.imul(value ^ (value >>> 15), value | 1);
    value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  };
}

function standardNormal(random: () => number) {
  const first = Math.max(random(), Number.EPSILON);
  const second = random();
  return Math.sqrt(-2 * Math.log(first)) * Math.cos(2 * Math.PI * second);
}

function buildReadings(days: number, revision: number): Reading[] {
  const points = days * 24;
  const start = Date.now() - (points - 1) * 60 * 60 * 1000;
  const random = createRandom((0xa511e9b3 ^ (days * 12345) ^ (revision * 2654435761)) >>> 0);
  return Array.from({ length: points }, (_, index) => {
    const supply = 80 + 2.5 * standardNormal(random);
    const ambient = 10 + 5 * standardNormal(random);
    const flow = Math.max(0.1, 5 + 0.5 * standardNormal(random));
    const returned = ambient + (supply - ambient) *
      Math.exp(-(0.5 * 1000) / (flow * 4184));
    const delivered = (flow * 4184 * (supply - returned)) / 1000;
    return {
      time: start + index * 60 * 60 * 1000,
      supply,
      returned,
      delivered,
      ambient,
      flow,
      anomaly: returned > 65,
    };
  });
}

const dateTime = (time: number, compact = false) =>
  new Intl.DateTimeFormat('en-GB', compact
    ? { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }
    : { day: '2-digit', month: 'short', hour: '2-digit' },
  ).format(time);

const chartTooltipStyle = {
  background: '#111821',
  border: '1px solid #34404d',
  borderRadius: 8,
  color: '#dce5ed',
  fontSize: 12,
  fontFamily: 'DM Mono, monospace',
  padding: '10px 12px',
};

function TemperatureTooltip({ active, payload, label }: {
  active?: boolean; payload?: Array<{ name: string; value: number; color: string }>; label?: number;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div style={chartTooltipStyle}>
      <div className="mb-2 text-slate-400">{label ? dateTime(label, true) : ''}</div>
      {payload.map((entry) => (
        <div key={entry.name} className="flex min-w-40 justify-between gap-5 py-0.5">
          <span style={{ color: entry.color }}>{entry.name}</span>
          <span>{entry.value.toFixed(1)} °C</span>
        </div>
      ))}
    </div>
  );
}

function HeatTooltip({ active, payload, label }: {
  active?: boolean; payload?: Array<{ value: number }>; label?: number;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div style={chartTooltipStyle}>
      <div className="mb-2 text-slate-400">{label ? dateTime(label, true) : ''}</div>
      <div className="flex min-w-40 justify-between gap-5">
        <span className="text-teal-300">Delivered heat</span>
        <span>{payload[0].value.toFixed(0)} kW</span>
      </div>
    </div>
  );
}

function MetricCard({ label, value, unit, icon: Icon, note, alert = false }: {
  label: string; value: string; unit: string; icon: typeof Thermometer; note: string; alert?: boolean;
}) {
  return (
    <article className={`panel metric-card p-5 ${alert ? 'alert' : ''}`} data-testid={`metric-${label.toLowerCase().replaceAll(' ', '-')}`}>
      <div className="flex items-start justify-between">
        <div className="eyebrow">{label}</div>
        <div className={`rounded-md border p-2 ${alert ? 'border-rose-400/20 bg-rose-400/10 text-rose-300' : 'border-teal-400/15 bg-teal-400/8 text-teal-300'}`}>
          <Icon size={16} strokeWidth={1.8} aria-hidden="true" />
        </div>
      </div>
      <div className="mt-4 flex items-baseline gap-2">
        <span className={`mono text-[30px] leading-none tracking-[-.055em] ${alert ? 'text-rose-300' : 'text-slate-100'}`}>{value}</span>
        <span className="text-xs text-slate-500">{unit}</span>
      </div>
      <div className={`mt-3 flex items-center gap-1.5 text-[11px] ${alert ? 'text-rose-300' : 'text-slate-500'}`}>
        {alert && Number(value) > 0 ? <AlertTriangle size={12} /> : <Activity size={12} />}
        <span>{note}</span>
      </div>
    </article>
  );
}

function App() {
  const [days, setDays] = useState(30);
  const [revision, setRevision] = useState(0);
  const readings = useMemo(() => buildReadings(days, revision), [days, revision]);
  const avgSupply = readings.reduce((sum, point) => sum + point.supply, 0) / readings.length;
  const avgReturn = readings.reduce((sum, point) => sum + point.returned, 0) / readings.length;
  const peakHeat = Math.max(...readings.map((point) => point.delivered));
  const anomalyCount = readings.filter((point) => point.anomaly).length;
  const latest = readings[readings.length - 1];

  const downloadCsv = () => {
    const header = 'timestamp,supply_c,predicted_return_c,delivered_heat_kw,ambient_c,flow_kg_s,anomaly';
    const rows = readings.map((point) => [
      new Date(point.time).toISOString(), point.supply.toFixed(2),
      point.returned.toFixed(2), point.delivered.toFixed(2),
      point.ambient.toFixed(2), point.flow.toFixed(3), point.anomaly,
    ].join(','));
    const blob = new Blob([[header, ...rows].join('\n')], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `district-heat-${days}d-telemetry.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <main className="dashboard-shell min-h-[100dvh]">
      <header className="topbar sticky top-0 z-20 flex items-center justify-between px-4 sm:px-7">
        <div className="flex min-w-0 items-center gap-3">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-teal-300/20 bg-teal-300/10 text-teal-300">
            <Flame size={19} strokeWidth={1.8} aria-hidden="true" />
          </div>
          <div className="min-w-0">
            <div className="truncate text-[13px] font-bold tracking-[-.02em] text-slate-100">HEAT / TWIN</div>
            <div className="hidden text-[10px] tracking-[.14em] text-slate-500 sm:block">NETWORK OPERATIONS</div>
          </div>
          <div className="ml-2 hidden h-7 w-px bg-slate-700/70 md:block" />
          <div className="hidden text-xs text-slate-400 md:block">North Quay District · Loop 01</div>
        </div>
        <div className="flex items-center gap-2 sm:gap-4">
          <div className="flex items-center gap-2 rounded-full border border-teal-400/15 bg-teal-400/5 px-3 py-1.5 text-[11px] text-teal-200">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-teal-400 opacity-30" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-teal-400" />
            </span>
            <span className="hidden sm:inline">Model active</span>
            <span className="sm:hidden">Active</span>
          </div>
          <button type="button" onClick={() => setRevision((current) => current + 1)} className="flex h-9 items-center gap-2 rounded-md border border-slate-700/80 px-3 text-xs text-slate-300 transition-colors hover:border-teal-400/40 hover:text-teal-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-400" data-testid="button-refresh">
            <RefreshCw size={14} aria-hidden="true" />
            <span className="hidden sm:inline">Regenerate telemetry</span>
            <span className="sm:hidden">Refresh</span>
          </button>
        </div>
      </header>

      <div className="mx-auto max-w-[1512px] px-4 pb-10 pt-7 sm:px-7 lg:px-9">
        <section className="enter mb-6 flex flex-col justify-between gap-5 lg:flex-row lg:items-end">
          <div>
            <div className="mb-2 flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[.16em] text-teal-300">
              <span className="h-px w-5 bg-teal-400" /> Operations intelligence
            </div>
            <h1 className="text-[27px] font-semibold leading-tight tracking-[-.045em] text-slate-100 sm:text-[32px]">Network overview</h1>
            <p className="mt-1.5 text-sm text-slate-400">Live thermal performance and modelled return conditions.</p>
          </div>
          <div className="flex flex-wrap items-center gap-x-5 gap-y-2">
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <Clock3 size={14} className="text-slate-500" aria-hidden="true" />
              <span>Latest reading</span>
              <span className="mono text-slate-200">{dateTime(latest.time, true)}</span>
            </div>
            <button type="button" onClick={downloadCsv} className="flex h-9 items-center gap-2 rounded-md border border-slate-700/80 px-3 text-xs font-medium text-slate-300 transition-colors hover:border-slate-500 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-400" data-testid="button-export">
              <Download size={14} aria-hidden="true" /> Export CSV
            </button>
          </div>
        </section>

        <section className="panel enter enter-delay-1 mb-5 flex flex-col gap-4 px-4 py-3.5 sm:flex-row sm:items-center sm:justify-between sm:px-5" aria-label="Historical range controls">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-slate-800 text-slate-400">
              <SlidersHorizontal size={15} aria-hidden="true" />
            </div>
            <div>
              <div className="text-xs font-semibold text-slate-200">Historical window</div>
              <div className="text-[10px] text-slate-500">Hourly modelled telemetry</div>
            </div>
          </div>
          <div className="flex w-full items-center gap-4 sm:max-w-[390px]">
            <input
              aria-label="Historical range in days"
              className="range-slider min-w-0 flex-1"
              data-testid="input-history-range"
              type="range"
              min="7"
              max="60"
              value={days}
              onChange={(event) => setDays(Number(event.target.value))}
            />
            <span className="mono w-[70px] text-right text-xs text-slate-200" aria-live="polite">{days} days</span>
          </div>
          <div className="hidden items-center gap-2 text-[10px] text-slate-500 lg:flex">
            <Waves size={14} className="text-sky-400" aria-hidden="true" />
            <span>Hourly resolution</span>
          </div>
        </section>

        <section className="mb-5 grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4" aria-label="Network performance metrics">
          <MetricCard label="Average supply temperature" value={avgSupply.toFixed(1)} unit="°C" icon={Thermometer} note="Across selected window" />
          <MetricCard label="Average return temperature" value={avgReturn.toFixed(1)} unit="°C" icon={Waves} note="Predicted from flow and ambient" />
          <MetricCard label="Peak heat delivered" value={peakHeat.toFixed(0)} unit="kW" icon={Zap} note="Maximum hourly delivery" />
          <MetricCard label="Anomaly count" value={String(anomalyCount)} unit="events" icon={AlertTriangle} alert={anomalyCount > 0} note={anomalyCount > 0 ? 'Return temperature above 65 °C' : 'No high-return events detected'} />
        </section>

        <section className="grid grid-cols-1 gap-5 xl:grid-cols-[1.65fr_1fr]">
          <article className="panel enter enter-delay-2 min-w-0 p-4 sm:p-5">
            <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
              <div>
                <div className="eyebrow">Thermal profile</div>
                <h2 className="mt-1 text-sm font-semibold text-slate-100">Supply &amp; predicted return</h2>
              </div>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-[10px] text-slate-400">
                <span className="flex items-center gap-2"><span className="h-[2px] w-4 bg-teal-400" />Supply</span>
                <span className="flex items-center gap-2"><span className="h-[2px] w-4 bg-sky-400" />Predicted return</span>
                <span className="flex items-center gap-2"><span className="h-2 w-2 rounded-full bg-rose-400" />Above 65 °C</span>
              </div>
            </div>
            <div className="h-[270px] w-full sm:h-[310px]" role="img" aria-label={`Hourly supply and predicted return temperature history for ${days} days`}>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={readings} margin={{ top: 8, right: 8, bottom: 2, left: 0 }}>
                  <CartesianGrid className="chart-grid" vertical={false} />
                  <XAxis dataKey="time" type="number" scale="time" domain={['dataMin', 'dataMax']} tickFormatter={(value) => new Intl.DateTimeFormat('en-GB', { day: '2-digit', month: 'short' }).format(value)} tickCount={6} minTickGap={34} tickLine={false} axisLine={false} className="chart-axis" />
                  <YAxis domain={['dataMin - 4', 'dataMax + 4']} tickFormatter={(value) => `${Math.round(value)}°`} tickLine={false} axisLine={false} className="chart-axis" width={48} />
                  <Tooltip content={<TemperatureTooltip />} />
                  <ReferenceLine y={65} stroke="#ed7771" strokeDasharray="4 5" strokeOpacity={0.55} />
                  <Line name="Supply" dataKey="supply" type="monotone" stroke="#2ac5b0" strokeWidth={2} dot={false} isAnimationActive={false} activeDot={{ r: 4, fill: '#2ac5b0', stroke: '#0f171c', strokeWidth: 2 }} />
                  <Line name="Predicted return" dataKey="returned" type="monotone" stroke="#5ba9db" strokeWidth={1.8} dot={false} isAnimationActive={false} activeDot={{ r: 4, fill: '#5ba9db', stroke: '#0f171c', strokeWidth: 2 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-1 flex items-center gap-2 border-t border-slate-800/80 pt-3 text-[10px] leading-relaxed text-slate-500">
              <ArrowDownRight size={13} className="shrink-0 text-sky-400" aria-hidden="true" />
              Return temperature is estimated from supply, ambient conditions and measured flow.
            </div>
          </article>

          <article className="panel enter enter-delay-2 min-w-0 p-4 sm:p-5">
            <div className="mb-4 flex items-start justify-between gap-2">
              <div>
                <div className="eyebrow">Load profile</div>
                <h2 className="mt-1 text-sm font-semibold text-slate-100">Delivered heat</h2>
              </div>
              <div className="rounded-md border border-sky-400/15 bg-sky-400/5 px-2.5 py-1 text-[10px] text-sky-200">Hourly · kW</div>
            </div>
            <div className="h-[270px] w-full sm:h-[310px]" role="img" aria-label={`Hourly delivered heat for ${days} days`}>
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={readings} margin={{ top: 8, right: 4, bottom: 2, left: 0 }}>
                  <defs>
                    <linearGradient id="heatFill" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#22bba8" stopOpacity={0.3} />
                      <stop offset="92%" stopColor="#22bba8" stopOpacity={0.01} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid className="chart-grid" vertical={false} />
                  <XAxis dataKey="time" type="number" scale="time" domain={['dataMin', 'dataMax']} tickFormatter={(value) => new Intl.DateTimeFormat('en-GB', { day: '2-digit', month: 'short' }).format(value)} tickCount={5} minTickGap={34} tickLine={false} axisLine={false} className="chart-axis" />
                  <YAxis tickFormatter={(value) => `${Math.round(value)} kW`} tickLine={false} axisLine={false} className="chart-axis" width={52} />
                  <Tooltip content={<HeatTooltip />} />
                  <Area name="Delivered heat" dataKey="delivered" type="monotone" stroke="#27c2af" strokeWidth={2} fill="url(#heatFill)" isAnimationActive={false} activeDot={{ r: 4, fill: '#27c2af', stroke: '#0f171c', strokeWidth: 2 }} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-1 flex items-center gap-2 border-t border-slate-800/80 pt-3 text-[10px] text-slate-500">
              <Gauge size={13} className="shrink-0 text-teal-400" aria-hidden="true" />
              Calculated from flow rate and supply-to-return temperature difference.
            </div>
          </article>
        </section>

        <details className="panel enter enter-delay-3 mt-5 overflow-hidden">
          <summary className="flex cursor-pointer list-none items-center justify-between gap-4 px-4 py-4 outline-none transition-colors hover:bg-white/[.02] focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-teal-400 sm:px-5 [&::-webkit-details-marker]:hidden">
            <div className="flex min-w-0 items-center gap-3">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md border border-slate-700 bg-slate-800/70 text-slate-300"><Activity size={15} aria-hidden="true" /></div>
              <div className="min-w-0">
                <div className="text-xs font-semibold text-slate-100">Raw telemetry</div>
                <div className="mt-0.5 text-[10px] text-slate-500">Hourly readings · newest first · {readings.length.toLocaleString()} records</div>
              </div>
            </div>
            <span className="flex shrink-0 items-center gap-2 text-[10px] font-semibold uppercase tracking-[.12em] text-slate-400">
              <span className="hidden sm:inline">Expand data</span>
              <ChevronDown size={15} aria-hidden="true" />
            </span>
          </summary>
          <div className="table-wrap max-h-[420px] overflow-auto border-t border-slate-800/90">
            <table className="w-full min-w-[790px] border-collapse text-left text-xs">
              <caption className="sr-only">Hourly generated district heating telemetry readings</caption>
              <thead className="sticky top-0 z-10 bg-[#151b23] text-[10px] uppercase tracking-[.1em] text-slate-500">
                <tr>
                  <th scope="col" className="px-5 py-3 font-semibold">Timestamp</th>
                  <th scope="col" className="px-4 py-3 text-right font-semibold">Supply °C</th>
                  <th scope="col" className="px-4 py-3 text-right font-semibold">Return °C</th>
                  <th scope="col" className="px-4 py-3 text-right font-semibold">Heat kW</th>
                  <th scope="col" className="px-4 py-3 text-right font-semibold">Ambient °C</th>
                  <th scope="col" className="px-4 py-3 text-right font-semibold">Flow kg/s</th>
                  <th scope="col" className="px-5 py-3 text-right font-semibold">Condition</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/70">
                {[...readings].reverse().map((point, index) => (
                  <tr key={point.time} className="transition-colors hover:bg-white/[.025]" data-testid={`row-reading-${index}`}>
                    <td className="mono whitespace-nowrap px-5 py-2.5 text-slate-300">{dateTime(point.time, true)}</td>
                    <td className="mono px-4 py-2.5 text-right text-teal-200">{point.supply.toFixed(1)}</td>
                    <td className={`mono px-4 py-2.5 text-right ${point.anomaly ? 'font-medium text-rose-300' : 'text-sky-200'}`}>{point.returned.toFixed(1)}</td>
                    <td className="mono px-4 py-2.5 text-right text-slate-300">{point.delivered.toFixed(0)}</td>
                    <td className="mono px-4 py-2.5 text-right text-slate-400">{point.ambient.toFixed(1)}</td>
                    <td className="mono px-4 py-2.5 text-right text-slate-400">{point.flow.toFixed(2)}</td>
                    <td className="px-5 py-2.5 text-right">
                      <span className={`inline-flex items-center gap-1.5 whitespace-nowrap text-[10px] ${point.anomaly ? 'text-rose-300' : 'text-slate-500'}`}>
                        <span className={`h-1.5 w-1.5 rounded-full ${point.anomaly ? 'bg-rose-400' : 'bg-slate-600'}`} />
                        {point.anomaly ? 'High return' : 'Within range'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </details>

        <footer className="mt-5 flex flex-col gap-2 border-t border-slate-800/70 pt-4 text-[10px] text-slate-600 sm:flex-row sm:items-center sm:justify-between">
          <span>District heating digital twin <span className="px-1.5 text-slate-700">/</span> Proof of concept</span>
          <span className="flex items-center gap-2"><ArrowUpRight size={11} aria-hidden="true" /> Modelled hourly telemetry · all values calculated in browser</span>
        </footer>
      </div>
    </main>
  );
}

export default App;
